<template>
  <div class="container">
    <Calculator @add-calculation="addCalculation" />
    <History :calculations="calculations" />
  </div>
</template>

<script>
import Calculator from './components/Calculator.vue';
import History from './components/History.vue';

export default {
  components: {
    Calculator,
    History
  },
  data() {
    return {
      calculations: []
    }
  },
  methods: {
    addCalculation(calculation) {
      this.calculations.push(calculation);
    }
  }
}
</script>


