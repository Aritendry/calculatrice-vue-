<template>
  <div class="container">
    <header>CALCULATOR</header>
    <div id="ZoneText">
      <h1>{{ Response }}</h1>
    </div>
    <div id="button">
      <button class="command" @click="sup">sup</button>
      <button class="command" @click="clear">C</button>
      <button class="sign"    @click="AjoutSigne('%')">%</button>
      <button class="sign"    @click="AjoutSigne('/')">/</button>
      <button class="number"  @click="AjoutNombre(7)">7</button>
      <button class="number"  @click="AjoutNombre(8)">8</button>
      <button class="number"  @click="AjoutNombre(9)">9</button>
      <button class="sign"    @click="AjoutSigne('*')">x</button>
      <button class="number"  @click="AjoutNombre(4)">4</button>
      <button class="number"  @click="AjoutNombre(5)">5</button>
      <button class="number"  @click="AjoutNombre(6)">6</button>
      <button class="sign"    @click="AjoutSigne('+')">+</button>
      <button class="number"  @click="AjoutNombre(1)">1</button>
      <button class="number"  @click="AjoutNombre(2)">2</button>
      <button class="number"  @click="AjoutNombre(3)">3</button>
      <button class="sign"    @click="AjoutSigne('-')">-</button>
      <button class="number"  @click="AjoutNombreDouble(0)">00</button>
      <button class="number"  @click="AjoutNombre(0)">0</button>
      <button class="sign"    @click="AjoutSigne('.')">,</button>
      <button class="sign"    @click="equal">=</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      Response: ""
    };
  },
  methods: {
    AjoutNombre(number) {
      this.Response += number;
    },
    AjoutNombreDouble(number) {
      this.Response += number;
      this.Response += number;
    },
    AjoutSigne(sign) {
      this.Response += sign;
    },
    clear() {
      this.Response = "";
    },
    sup() {
      this.Response = this.Response.slice(0, -1);
    },
    equal() {
      try {
        const result = eval(this.Response);
        this.$emit('add-calculation', `${this.Response} = ${result}`);
        this.Response = result;
      } catch (e) {
        this.Response = "Erreur";
      }
    }
  }
}
</script>


