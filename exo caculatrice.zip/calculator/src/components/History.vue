<template>
  <div class="history">
    <h2>Historique des calculs</h2>
    <ul>
      <li v-for="(calculation, index) in calculations" :key="index">
        {{ calculation }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    calculations: {
      type: Array,
      required: true
    }
  }
}
</script>

<style>
.history {
  margin-top: 20px;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 10px;
}
.history h2 {
  margin-bottom: 10px;
}
.history ul {
  list-style-type: none;
  padding: 0;
}
.history li {
  margin-bottom: 5px;
}
</style>

